#pragma once

enum class SceneType
{
  NONE,
  TITLE_SCENE,
  GAME, 
  LEADERBOARD,
};
