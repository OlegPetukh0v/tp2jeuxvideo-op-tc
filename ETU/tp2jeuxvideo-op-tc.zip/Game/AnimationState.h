#pragma once

enum class State
{
  NONE,
  STANDARD_ENEMY,
  SHIP,
  BOSS,
};